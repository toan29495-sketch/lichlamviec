LỊCH LÀM VIỆC THÁNG v2.0

- Lịch theo tháng dạng lưới 7 cột, từ Thứ 2 đến Chủ nhật.
- Mỗi ngày trong tháng có một ô trống để tự ghi; không có nhãn trường.
- Điều hướng tháng trước/tháng này/tháng sau.
- Tự lưu cục bộ, sao chép nội dung ngày tương ứng của tháng trước, xuất TXT/CSV, sao lưu/khôi phục JSON.
- APK xuất file qua hộp thoại Android “Lưu vào”; không cần quyền truy cập toàn bộ bộ nhớ hoặc INTERNET.

TẠO APK:
1. Cài Android Studio từ https://developer.android.com/studio
2. Giải nén ZIP, mở thư mục có settings.gradle.
3. Chờ Gradle Sync, cài Android SDK Platform 35 nếu được hỏi.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK debug: app/build/outputs/apk/debug/app-debug.apk

Đây là mã nguồn, chưa được biên dịch/kiểm thử thực tế trong môi trường tạo tệp. Sao lưu JSON trước khi gỡ app hoặc xóa dữ liệu.

BUILD APK ONLINE WITHOUT ANDROID STUDIO (GitHub Actions)
1. On your phone browser, sign in/create account at https://github.com
2. Create a new repository (private is fine).
3. Upload the contents of this project ZIP to the repository. Ensure settings.gradle and app/ are at repository root, and also upload .github/workflows/build-apk.yml.
4. Open the repository's Actions tab. If asked, enable Actions.
5. Select "Build Lich Lam Viec APK" > Run workflow.
6. Wait for the run to finish successfully. Open that run and download artifact "Lich-Lam-Viec-Thang-APK".
7. Extract the downloaded artifact ZIP; it contains app-debug.apk. Install on your Android phone.
This workflow builds a debug APK. Keep your repository private if you do not want the source publicly visible. GitHub Actions availability/quotas depend on account and repository settings.
