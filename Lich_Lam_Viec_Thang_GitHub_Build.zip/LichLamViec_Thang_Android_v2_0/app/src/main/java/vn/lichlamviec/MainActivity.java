package vn.lichlamviec;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.*;
import android.widget.Toast;
import java.io.OutputStream;
public class MainActivity extends Activity {
 private static final int CREATE_FILE=7101; private static final int OPEN_FILE=7102; private WebView web; private String fileName,fileMime; private byte[] fileBytes; private ValueCallback<Uri[]> filePathCallback;
 @Override public void onCreate(Bundle b){super.onCreate(b);web=new WebView(this);WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(true);s.setAllowContentAccess(false);s.setSupportMultipleWindows(false);web.setWebViewClient(new WebViewClient());web.setWebChromeClient(new WebChromeClient(){@Override public boolean onShowFileChooser(WebView w,ValueCallback<Uri[]> callback,FileChooserParams params){if(filePathCallback!=null)filePathCallback.onReceiveValue(null);filePathCallback=callback;try{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivityForResult(i,OPEN_FILE);return true;}catch(Exception e){filePathCallback=null;return false;}}});web.addJavascriptInterface(new Bridge(),"AndroidBridge");setContentView(web);web.loadUrl("file:///android_asset/index.html");}
 private class Bridge { @JavascriptInterface public void saveFile(String name,String mime,String b64){runOnUiThread(()->{try{fileName=name;fileMime=mime.split(";")[0];fileBytes=Base64.decode(b64,Base64.DEFAULT);Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType(fileMime);i.putExtra(Intent.EXTRA_TITLE,fileName);startActivityForResult(i,CREATE_FILE);}catch(Exception e){Toast.makeText(MainActivity.this,"Không mở được hộp thoại lưu file",Toast.LENGTH_LONG).show();}});} }
 @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);if(req==CREATE_FILE&&result==RESULT_OK&&data!=null&&data.getData()!=null&&fileBytes!=null){try(OutputStream out=getContentResolver().openOutputStream(data.getData(),"w")){if(out==null)throw new Exception();out.write(fileBytes);out.flush();Toast.makeText(this,"Đã lưu "+fileName,Toast.LENGTH_LONG).show();}catch(Exception e){Toast.makeText(this,"Lưu file thất bại",Toast.LENGTH_LONG).show();}}if(req==CREATE_FILE)fileBytes=null;if(req==OPEN_FILE&&filePathCallback!=null){Uri[] results=null;if(result==RESULT_OK&&data!=null&&data.getData()!=null)results=new Uri[]{data.getData()};filePathCallback.onReceiveValue(results);filePathCallback=null;}}
 @Override public void onBackPressed(){new android.app.AlertDialog.Builder(this).setMessage("Thoát ứng dụng?").setNegativeButton("Ở lại",(d,w)->{}).setPositiveButton("Thoát",(d,w)->finish()).show();}
}