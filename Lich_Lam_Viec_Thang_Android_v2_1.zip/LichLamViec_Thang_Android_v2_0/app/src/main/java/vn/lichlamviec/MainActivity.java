package vn.lichlamviec;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.*;
import android.widget.Toast;
import org.json.JSONObject;
import org.json.JSONException;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import java.io.IOException;

public class MainActivity extends Activity {
 private static final int CREATE_FILE=7101;
 private WebView web;
 private String fileName, fileMime;
 private byte[] fileBytes;

 @Override public void onCreate(Bundle b) {
  super.onCreate(b);
  web=new WebView(this);
  WebSettings s=web.getSettings();
  s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
  s.setAllowFileAccess(true); s.setAllowContentAccess(false);
  web.setWebViewClient(new WebViewClient());
  web.setWebChromeClient(new WebChromeClient());
  web.addJavascriptInterface(new Bridge(),"AndroidBridge");
  setContentView(web);
  web.loadUrl("file:///android_asset/index.html");
 }

 private class Bridge {
  @JavascriptInterface public void saveFile(String name,String mime,String b64) {
   runOnUiThread(()->{
    try { fileName=name; fileMime=mime.split(";")[0]; fileBytes=Base64.decode(b64,Base64.DEFAULT); showSaveDialog(); }
    catch(Exception e){ Toast.makeText(MainActivity.this,"Không thể chuẩn bị file",Toast.LENGTH_LONG).show(); }
   });
  }
  @JavascriptInterface public void saveXlsx(String b64) {
   runOnUiThread(()->{
    try {
     String json=new String(Base64.decode(b64,Base64.DEFAULT),StandardCharsets.UTF_8);
     JSONObject data=new JSONObject(json);
     fileName=String.format(java.util.Locale.US,"lich-lam-viec-%04d-%02d.xlsx",data.getInt("year"),data.getInt("month"));
     fileMime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
     fileBytes=makeXlsx(data);
     showSaveDialog();
    } catch(Exception e) {
     Toast.makeText(MainActivity.this,"Không tạo được Excel: "+e.getMessage(),Toast.LENGTH_LONG).show();
    }
   });
  }
 }
 private void showSaveDialog() {
  Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);
  i.addCategory(Intent.CATEGORY_OPENABLE); i.setType(fileMime);
  i.putExtra(Intent.EXTRA_TITLE,fileName); startActivityForResult(i,CREATE_FILE);
 }
 private byte[] makeXlsx(JSONObject data) throws Exception {
  int year=data.getInt("year"), month=data.getInt("month");
  JSONObject entries=data.optJSONObject("entries"); if(entries==null) entries=new JSONObject();
  String[] names={"Thứ 2","Thứ 3","Thứ 4","Thứ 5","Thứ 6","Thứ 7","Chủ nhật"};
  java.util.Calendar cal=java.util.Calendar.getInstance();
  cal.clear(); cal.set(year,month-1,1);
  int first=(cal.get(java.util.Calendar.DAY_OF_WEEK)+5)%7;
  int days=cal.getActualMaximum(java.util.Calendar.DAY_OF_MONTH);
  StringBuilder sheet=new StringBuilder();
  sheet.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>")
   .append("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><cols>");
  for(int c=1;c<=7;c++) sheet.append("<col min=\"").append(c).append("\" max=\"").append(c).append("\" width=\"22\" customWidth=\"1\"/>");
  sheet.append("</cols><sheetData>");
  sheet.append("<row r=\"1\" ht=\"26\" customHeight=\"1\">");
  for(int c=0;c<7;c++) cell(sheet,c+1,1,names[c],1);
  sheet.append("</row>");
  int day=1;
  for(int week=0;week<6;week++){
   int row=week+2;
   sheet.append("<row r=\"").append(row).append("\" ht=\"95\" customHeight=\"1\">");
   for(int col=0;col<7;col++){
    int slot=week*7+col;
    String value="";
    if(slot>=first && day<=days){
     String k=String.format(java.util.Locale.US,"%04d-%02d-%02d",year,month,day);
     JSONObject v=entries.optJSONObject(k);
     String content=v!=null?v.optString("content",""):entries.optString(k,"");
     value=day+(content.isEmpty()?"":"\n"+content);
     day++;
    }
    cell(sheet,col+1,row,value,2);
   }
   sheet.append("</row>");
  }
  sheet.append("</sheetData></worksheet>");
  ByteArrayOutputStream out=new ByteArrayOutputStream();
  ZipOutputStream zip=new ZipOutputStream(out);
  put(zip,"[Content_Types].xml","<?xml version=\"1.0\" encoding=\"UTF-8\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/><Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/></Types>");
  put(zip,"_rels/.rels","<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");
  put(zip,"xl/workbook.xml","<?xml version=\"1.0\" encoding=\"UTF-8\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets><sheet name=\"Lịch tháng\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>");
  put(zip,"xl/_rels/workbook.xml.rels","<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/><Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/></Relationships>");
  put(zip,"xl/styles.xml","<?xml version=\"1.0\" encoding=\"UTF-8\"?><styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><fonts count=\"2\"><font><sz val=\"11\"/><name val=\"Arial\"/></font><font><b/><sz val=\"11\"/><color rgb=\"FF18552C\"/><name val=\"Arial\"/></font></fonts><fills count=\"3\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill><fill><patternFill patternType=\"solid\"><fgColor rgb=\"FFE8F3EB\"/><bgColor indexed=\"64\"/></patternFill></fill></fills><borders count=\"2\"><border><left/><right/><top/><bottom/><diagonal/></border><border><left style=\"thin\"><color rgb=\"FFD7E1D9\"/></left><right style=\"thin\"><color rgb=\"FFD7E1D9\"/></right><top style=\"thin\"><color rgb=\"FFD7E1D9\"/></top><bottom style=\"thin\"><color rgb=\"FFD7E1D9\"/></bottom><diagonal/></border></borders><cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs><cellXfs count=\"3\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/><xf numFmtId=\"0\" fontId=\"1\" fillId=\"2\" borderId=\"1\" xfId=\"0\" applyAlignment=\"1\"><alignment horizontal=\"center\" vertical=\"center\" wrapText=\"1\"/></xf><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"1\" xfId=\"0\" applyAlignment=\"1\"><alignment vertical=\"top\" wrapText=\"1\"/></xf></cellXfs></styleSheet>");
  put(zip,"xl/worksheets/sheet1.xml",sheet.toString());
  zip.close(); return out.toByteArray();
 }
 private void cell(StringBuilder s,int col,int row,String value,int style){
  String ref=colName(col)+row;
  s.append("<c r=\"").append(ref).append("\" t=\"inlineStr\" s=\"").append(style).append("\"><is><t xml:space=\"preserve\">").append(xml(value)).append("</t></is></c>");
 }
 private String colName(int n){String s="";while(n>0){int r=(n-1)%26;s=(char)('A'+r)+s;n=(n-1)/26;}return s;}
 private String xml(String s){return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&apos;");}
 private void put(ZipOutputStream z,String name,String content)throws IOException{z.putNextEntry(new ZipEntry(name));z.write(content.getBytes(StandardCharsets.UTF_8));z.closeEntry();}
 @Override protected void onActivityResult(int req,int result,Intent data){
  super.onActivityResult(req,result,data);
  if(req==CREATE_FILE&&result==RESULT_OK&&data!=null&&data.getData()!=null&&fileBytes!=null){
   try(OutputStream out=getContentResolver().openOutputStream(data.getData(),"w")){
    if(out==null)throw new IOException("Không mở được file");out.write(fileBytes);out.flush();
    Toast.makeText(this,"Đã lưu "+fileName,Toast.LENGTH_LONG).show();
   }catch(Exception e){Toast.makeText(this,"Lưu file thất bại",Toast.LENGTH_LONG).show();}
  }
  if(req==CREATE_FILE)fileBytes=null;
 }
 @Override public void onBackPressed(){new android.app.AlertDialog.Builder(this).setMessage("Thoát ứng dụng?").setNegativeButton("Ở lại",(d,w)->{}).setPositiveButton("Thoát",(d,w)->finish()).show();}
}