LỊCH LÀM VIỆC THÁNG v2.1 — XUẤT EXCEL XLSX

- Lịch dạng tháng, 7 cột từ Thứ 2 đến Chủ nhật.
- Mỗi ngày có ô trống để tự ghi; tự lưu ngoại tuyến.
- Chuyển tháng, sao chép ngày tương ứng từ tháng trước.
- Xuất TXT, Excel XLSX, sao lưu/khôi phục JSON. Đã bỏ chức năng xuất CSV.
- XLSX được tạo trực tiếp bằng mã Android, có 7 cột, hàng tiêu đề, ô có viền và tự xuống dòng.
- Xuất file qua hộp thoại Android “Lưu vào”; không yêu cầu quyền truy cập toàn bộ bộ nhớ hay INTERNET.

TẠO APK TRÊN GITHUB ACTIONS
- Đặt source project trong repository hoặc dùng workflow để giải nén ZIP.
- Build command: gradle --no-daemon assembleDebug
- APK output: app/build/outputs/apk/debug/app-debug.apk

TẠO APK TRÊN ANDROID STUDIO
1. Mở thư mục có settings.gradle.
2. Chờ Gradle Sync và cài SDK Platform 35 nếu được hỏi.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).

Lưu ý: Mã nguồn chưa được build/test thực tế trong môi trường tạo tệp. Hãy kiểm thử file XLSX bằng Excel/Google Sheets và sao lưu JSON định kỳ.
